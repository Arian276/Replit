package com.barriletecosmicotv.model

data class Category(
    val name: String,
    val count: Int,
    val displayName: String
)